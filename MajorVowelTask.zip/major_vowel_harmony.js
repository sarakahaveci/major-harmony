const isHasMajorVowelHarmony = (word) => {
    return false;
}

export default isHasMajorVowelHarmony;